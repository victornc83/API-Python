import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='victornieto',
    application_name='todo-list-serverless',
    app_uid='BmLJ6dhCj68lgGYdwm',
    org_uid='2e14332f-fc14-4a7b-871c-e806999920a4',
    deployment_uid='b5c0548e-c6c3-465c-9a88-aab444087547',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-get', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/get.get')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
